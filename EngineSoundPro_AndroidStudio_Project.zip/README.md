# EngineSound Pro

Android Studio project for an original engine sound simulator prototype.

## Included
- Jetpack Compose dark dashboard
- RPM and speed readouts
- Throttle and brake sliders
- Six gears
- Single, V-Twin, Inline-4 and V8 profile choices
- Adjustable RPM limiter and master volume
- Realtime synthesized engine tone using Android AudioTrack

## Important
This is an original synthesized prototype. It does not contain or reuse proprietary SDMV EngineSound source code or extracted sound assets. The sound is a basic harmonic approximation and is not yet a physically accurate engine model.

## Build APK
1. Open this folder in Android Studio.
2. Allow Gradle sync and install Android SDK 35 if prompted.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`

Minimum Android version: Android 8.0 (API 26).
