package com.farhan.enginesoundpro

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.sin
import kotlin.math.max
import kotlin.math.min

/**
 * Lightweight synthesized engine tone. This is an original approximation,
 * not extracted audio from SDMV EngineSound.
 */
class EngineAudio {
    @Volatile private var rpm = 900f
    @Volatile private var throttle = 0f
    @Volatile private var masterVolume = 0.55f
    @Volatile private var cylinders = 1
    @Volatile private var running = false
    private var audioTrack: AudioTrack? = null
    private var worker: Thread? = null
    private val sampleRate = 44100
    private var phase = 0.0

    fun update(rpmValue: Float, throttleValue: Float, volume: Float, cylinderCount: Int) {
        rpm = rpmValue.coerceIn(700f, 14000f)
        throttle = throttleValue.coerceIn(0f, 1f)
        masterVolume = volume.coerceIn(0f, 1f)
        cylinders = cylinderCount.coerceIn(1, 4)
    }

    @Synchronized fun start() {
        if (running) return
        val minBuffer = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferBytes = max(minBuffer, 4096)
        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufferBytes)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        audioTrack?.play()
        running = true
        worker = Thread {
            val samples = ShortArray(1024)
            while (running) {
                val currentRpm = rpm
                val currentThrottle = throttle
                val firingHz = (currentRpm / 60.0 * cylinders / 2.0).coerceAtLeast(8.0)
                val fundamental = firingHz.coerceAtMost(180.0)
                val drive = 0.12 + currentThrottle * 0.55
                for (i in samples.indices) {
                    phase += 2.0 * PI * fundamental / sampleRate
                    if (phase > 2.0 * PI) phase -= 2.0 * PI
                    val pulse = sin(phase) +
                        0.48 * sin(phase * 2.0) +
                        0.24 * sin(phase * 3.0) +
                        0.12 * sin(phase * 5.0)
                    val rasp = sin(phase * 7.0 + sin(phase * 0.5) * 0.7)
                    val mixed = (pulse * 0.16 + rasp * (0.035 + currentThrottle * 0.08)) * drive
                    val value = (mixed * masterVolume * 15000.0).toInt()
                    samples[i] = value.coerceIn(-32768, 32767).toShort()
                }
                audioTrack?.write(samples, 0, samples.size)
            }
        }.apply { name = "EngineAudioThread"; priority = Thread.MAX_PRIORITY; start() }
    }

    @Synchronized fun stop() {
        running = false
        worker?.join(300)
        worker = null
        audioTrack?.pause()
        audioTrack?.flush()
        audioTrack?.release()
        audioTrack = null
    }
}
