package com.farhan.enginesoundpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private val Bg = Color(0xFF090D12)
private val Panel = Color(0xFF151D26)
private val Accent = Color(0xFFFF6B35)
private val Muted = Color(0xFF91A0AE)
private val Green = Color(0xFF47D7A0)

class MainActivity : ComponentActivity() {
    private val audio = EngineAudio()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Bg, surface = Panel, primary = Accent,
                    secondary = Green, onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                EngineScreen(audio)
            }
        }
    }

    override fun onDestroy() {
        audio.stop()
        super.onDestroy()
    }
}

@Composable
private fun EngineScreen(audio: EngineAudio) {
    var throttle by remember { mutableFloatStateOf(0f) }
    var brake by remember { mutableFloatStateOf(0f) }
    var rpm by remember { mutableFloatStateOf(900f) }
    var speed by remember { mutableFloatStateOf(0f) }
    var gear by remember { mutableIntStateOf(1) }
    var volume by remember { mutableFloatStateOf(0.55f) }
    var running by remember { mutableStateOf(false) }
    var engineType by remember { mutableStateOf("Single") }
    var limiter by remember { mutableFloatStateOf(11000f) }

    val cylinders = when (engineType) {
        "V-Twin" -> 2
        "Inline-4" -> 4
        "V8" -> 4
        else -> 1
    }

    LaunchedEffect(running, throttle, brake, gear, limiter, volume, engineType) {
        while (true) {
            val target = if (running) {
                (900f + throttle * (limiter - 900f) * (0.48f + gear * 0.085f))
                    .coerceAtMost(limiter)
            } else 0f
            val idle = if (running) 900f else 0f
            val desired = if (running) maxOf(idle, target) else 0f
            rpm += (desired - rpm) * 0.10f
            val gearRatio = (7 - gear).coerceAtLeast(1)
            val targetSpeed = if (running) (rpm / limiter * 180f * (7f / gearRatio)) else 0f
            speed += ((targetSpeed * (1f - brake * 0.92f)) - speed) * 0.045f
            speed = speed.coerceIn(0f, 260f)
            audio.update(rpm, throttle, volume, cylinders)
            delay(35)
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Bg)
            .verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ENGINE SOUND", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                Text("PRO  •  REALTIME SIMULATOR", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
            }
            Surface(color = Color(0xFF24352F), shape = RoundedCornerShape(20.dp)) {
                Text(if (running) "● LIVE" else "○ STANDBY", color = Green, modifier = Modifier.padding(10.dp), fontSize = 11.sp)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("ENGINE RPM", rpm.roundToInt().toString(), "RPM", Modifier.weight(1f), Accent)
            MetricCard("SPEED", speed.roundToInt().toString(), "KM/H", Modifier.weight(1f), Green)
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("ENGINE CONTROL", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("GEAR  $gear", color = Accent, fontWeight = FontWeight.Black, fontSize = 20.sp)
                }
                Text("THROTTLE", color = Muted, fontSize = 11.sp)
                Slider(value = throttle, onValueChange = { throttle = it }, enabled = running,
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent))
                Text("${(throttle * 100).roundToInt()}%  •  BRAKE", color = Muted, fontSize = 11.sp)
                Slider(value = brake, onValueChange = { brake = it },
                    colors = SliderDefaults.colors(thumbColor = Green, activeTrackColor = Green))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    (1..6).forEach { g ->
                        Button(
                            onClick = { gear = g },
                            modifier = Modifier.weight(1f).height(44.dp),
                            contentPadding = PaddingValues(0.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (gear == g) Accent else Color(0xFF27313D)
                            )
                        ) { Text("$g", fontWeight = FontWeight.Bold) }
                    }
                }
                Button(
                    onClick = {
                        running = !running
                        if (running) audio.start() else {
                            throttle = 0f
                            audio.stop()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (running) Color(0xFF9D3B32) else Green),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(if (running) "STOP ENGINE" else "START ENGINE",
                        color = Color.Black, fontWeight = FontWeight.Black)
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("ENGINE CONFIGURATION", fontWeight = FontWeight.Bold)
                Text("Engine profile", color = Muted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Single", "V-Twin", "Inline-4", "V8").forEach { type ->
                        FilterChip(
                            selected = engineType == type,
                            onClick = { engineType = type },
                            label = { Text(type, fontSize = 10.sp) }
                        )
                    }
                }
                Text("RPM LIMITER: ${limiter.roundToInt()} RPM", color = Muted, fontSize = 12.sp)
                Slider(value = limiter, onValueChange = { limiter = it }, valueRange = 4000f..14000f,
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent))
                Text("MASTER VOLUME: ${(volume * 100).roundToInt()}%", color = Muted, fontSize = 12.sp)
                Slider(value = volume, onValueChange = { volume = it },
                    colors = SliderDefaults.colors(thumbColor = Green, activeTrackColor = Green))
            }
        }
        Text("ENGINE SOUND PRO  •  BUILD 1.0", color = Muted, fontSize = 10.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun MetricCard(label: String, value: String, unit: String, modifier: Modifier, color: Color) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
            Row(verticalAlignment = Alignment.Bottom) {
                Text(value, color = color, fontSize = 32.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.width(5.dp))
                Text(unit, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(bottom = 6.dp))
            }
        }
    }
}
